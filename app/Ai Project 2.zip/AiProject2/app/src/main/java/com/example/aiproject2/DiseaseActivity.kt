package com.example.aiproject2

import android.os.Bundle

class DiseaseActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        layoutInflater.inflate(R.layout.activity_disease, findViewById(R.id.content_frame))

        setNavigationViewItemChecked(R.id.nav_disease)
    }
}
